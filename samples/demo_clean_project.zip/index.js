// Clean project using standard environment variable references
const port = process.env.PORT || 3000;
console.log(`Server starting on port ${port}`);
