const axios = require('axios');
const lodash = require('lodash');

// Exposed Personal Access Token
const GITHUB_PAT = "ghp_1234567890abcdefghijklmnopqrstuvwxyz";

console.log("App starting with token:", GITHUB_PAT);
